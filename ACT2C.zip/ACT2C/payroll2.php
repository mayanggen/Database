
    <?php
    $name = $_POST['name'];
    $total_days = $_POST['total_days'];
    $daily_rate = $_POST['daily_rate'];
    $cash_advance = $_POST['cash_advance'];
    $gross = $daily_rate * $total_days;
    $tax = $gross * 0.05;
    $sss = $gross * 0.02;
    $philhealth = $gross * 0.03;
    $pag_ibig = 50;
    $deductions = $cash_advance + $tax + $sss + $philhealth + $pag_ibig;
    $net = $gross - $deductions;

    echo "Name of Employee: $name <br> <br> Daily Rate: $daily_rate <br> <br> Days of Work: $total_days <br> <br>";
    echo "Gross Pay: $gross <br> <br> <strong> Deductions: </strong> <br> <br> ";
    echo "Tax: $tax <br> <br> SSS: $sss <br> <br> PhilHealth: $philhealth <br> <br> Pag-Ibig:$pag_ibig <br> <br>Cash Advance: $cash_advance <br> <br>" ;
    echo "Total Deductions: $deductions <br> Net Pay: $net";
    ?>

</html>